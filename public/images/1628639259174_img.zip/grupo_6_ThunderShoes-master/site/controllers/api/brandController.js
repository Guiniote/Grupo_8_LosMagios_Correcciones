const list = require('./brandController/list');


const controller = {
    list,
}

module.exports = controller;