module.exports = (req, res) => {
    let response = {
        meta: {
            status: 'ok'
        },
        data: {

        }
    }
    res.json(response)
}